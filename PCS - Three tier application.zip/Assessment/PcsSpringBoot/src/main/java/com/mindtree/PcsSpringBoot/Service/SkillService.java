package com.mindtree.PcsSpringBoot.Service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.mindtree.PcsSpringBoot.Entity.Employee;
import com.mindtree.PcsSpringBoot.Entity.Skill;

@Component
public interface SkillService {
	public Skill saveSkill(Skill skill);
	public Skill findBySId(int id);
	public List<Employee> getSearchList(String string);
}
