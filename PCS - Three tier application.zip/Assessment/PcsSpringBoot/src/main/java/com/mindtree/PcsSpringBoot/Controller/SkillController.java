package com.mindtree.PcsSpringBoot.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.PcsSpringBoot.Entity.Employee;
import com.mindtree.PcsSpringBoot.Entity.Skill;
import com.mindtree.PcsSpringBoot.Service.SkillService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class SkillController {

	@Autowired
	private SkillService skillService;

	@GetMapping("/addSkill/{id}")
	public ResponseEntity<Skill> getSkillById(@PathVariable int id) throws Exception {
		Skill skill = skillService.findBySId(id);
		return ResponseEntity.ok(skill);
	}

	@PostMapping("/addSkill")
	public Skill addSkill(@RequestBody Skill skill) throws Exception {
		Skill skills = new Skill(skill.getsId(), skill.getsTitle(), skill.getsCategory(), skill.getsDesc());
		skills = skillService.saveSkill(skills);
		return skills;
	}

	@PutMapping("/addSkillDel")
	public Skill deleteSkill(@RequestBody Skill skill) throws Exception {
		Skill skills = new Skill(skill.getsId(), "", "", "");
		skills = skillService.saveSkill(skills);
		return skills;
	}
	
	@GetMapping("/searchskill/{string}")
	public List<Employee> getAllEmployees(@PathVariable String string) {
		List<Employee> employee=skillService.getSearchList(string);
		return employee;
	}
}
