package com.mindtree.PcsSpringBoot.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.PcsSpringBoot.Entity.Employee;
import com.mindtree.PcsSpringBoot.Entity.Login;
import com.mindtree.PcsSpringBoot.Service.EmployeeService;
import com.mindtree.PcsSpringBoot.Service.LoginService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class LoginController {

	@Autowired
	private LoginService loginService;
	@Autowired
	private EmployeeService empService;

	@PostMapping("/register")
	public Employee createEmployee(@RequestBody Employee emp) throws Exception {
		
		Login loginUser = new Login(emp.getEmpEmail(), emp.getEmpPass(),emp.getEmpName(),emp.getEmpRole());
		loginService.saveLogin(loginUser);
		Employee employee = empService.saveEmployee(emp);
		return employee;

	}

	@PostMapping("/login")
	public Login checkPerson(@RequestBody Login login) throws Exception {
		String email = login.getEmail();
		String password = login.getPassword();
		Login loginUser = loginService.findByEmail(email);
		if (loginUser != null) {
			if (loginUser.getEmail().equalsIgnoreCase(email))
				if (loginUser.getPassword().equalsIgnoreCase(password)) {
					System.out.println("Correct user");
					return loginUser;
				} else {
					System.out.println("Incorrect password...");
					throw new Exception("Wrong password entered ! ! !");
				}
		} else {
			System.out.println("Invalid User");
			throw new Exception("User doesn't match");
		}
		return null;

	}

}
