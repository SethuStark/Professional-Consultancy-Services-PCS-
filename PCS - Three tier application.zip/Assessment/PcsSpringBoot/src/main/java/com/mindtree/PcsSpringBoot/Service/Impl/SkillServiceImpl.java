package com.mindtree.PcsSpringBoot.Service.Impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.PcsSpringBoot.Entity.Employee;
import com.mindtree.PcsSpringBoot.Entity.Skill;
import com.mindtree.PcsSpringBoot.Repository.EmployeeRepository;
import com.mindtree.PcsSpringBoot.Repository.SkillRepository;
import com.mindtree.PcsSpringBoot.Service.SkillService;

@Service
public class SkillServiceImpl implements SkillService {

	@Autowired
	private SkillRepository skillRepository;

	@Autowired
	private EmployeeRepository empRepository;

	@Override
	public Skill findBySId(int id) {
		Skill skill = skillRepository.findBysId(id);
		return skill;
	}

	@Override
	public Skill saveSkill(Skill skill) {

		return skillRepository.save(skill);
	}

	@Override
	public List<Employee> getSearchList(String string) {
		List<Employee> emp = new ArrayList<Employee>();
		List<Employee> employee = empRepository.findAll();
		Skill s;
		for (Employee e : employee) {
			s = e.getSkill();
			String[] res = s.getsTitle().split(" ", 0);
			for (String myStr : res) {
				System.out.println(myStr);
				if (string.equalsIgnoreCase(myStr)) {
					e.setSkill(new Skill(string));
					emp.add(e);

				}
			}

		}
		return emp;
	}

}
