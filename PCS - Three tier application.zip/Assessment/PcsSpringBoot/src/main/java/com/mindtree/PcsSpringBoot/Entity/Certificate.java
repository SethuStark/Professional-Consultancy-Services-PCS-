package com.mindtree.PcsSpringBoot.Entity;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="certificate")
public class Certificate {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cId;
	
	private String name;
	
	private int empID;
	
	private String type;
	
	@Column(name = "picByte", length = 2000)
	private byte[] picByte;

	public Certificate() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Certificate(int cId, String name, int empID, String type, byte[] picByte) {
		super();
		this.cId = cId;
		this.name = name;
		this.empID = empID;
		this.type = type;
		this.picByte = picByte;
	}

	public Certificate(String name, String type, byte[] picByte) {
		super();
		this.name = name;
		this.type = type;
		this.picByte = picByte;
	}



	public Certificate(String name, int empID, String type, byte[] picByte) {
		super();
		this.name = name;
		this.empID = empID;
		this.type = type;
		this.picByte = picByte;
	}



	@Override
	public String toString() {
		return "Certificate [cId=" + cId + ", name=" + name + ", empID=" + empID + ", type=" + type + ", picByte="
				+ Arrays.toString(picByte) + "]";
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public int getEmpID() {
		return empID;
	}



	public void setEmpID(int empID) {
		this.empID = empID;
	}



	public String getType() {
		return type;
	}



	public void setType(String type) {
		this.type = type;
	}



	public byte[] getPicByte() {
		return picByte;
	}



	public void setPicByte(byte[] picByte) {
		this.picByte = picByte;
	}



	



	public int getcId() {
		return cId;
	}

	public void setcId(int cId) {
		this.cId = cId;
	}
	
}
