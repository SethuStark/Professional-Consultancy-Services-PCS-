package com.mindtree.PcsSpringBoot.Service;

import org.springframework.stereotype.Component;

import com.mindtree.PcsSpringBoot.Entity.Login;

@Component
public interface LoginService {

	public void saveLogin(Login login);

	public Login findByEmail(String email);
}
