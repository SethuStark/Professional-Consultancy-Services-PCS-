package com.mindtree.PcsSpringBoot.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Component;

import com.mindtree.PcsSpringBoot.Entity.Employee;

@Component
public interface EmployeeService {
	public Employee saveEmployee(Employee emp);
	public Optional<Employee> findById(int id);
	public Employee findByEmpID(int id);
	public List<Employee> getEmployeeList();
}
