package com.mindtree.PcsSpringBoot.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.PcsSpringBoot.Entity.Skill;

@Repository
public interface SkillRepository extends JpaRepository<Skill, Integer> {
public Skill findBysId(int id);
}
