package com.mindtree.PcsSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcsSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
