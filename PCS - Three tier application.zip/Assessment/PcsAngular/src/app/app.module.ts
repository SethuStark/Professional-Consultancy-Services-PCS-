import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddCertificateComponent } from './Component/add-certificate/add-certificate.component';
import { AddEmployeeComponent } from './Component/add-employee/add-employee.component';
import { AddSkillComponent } from './Component/add-skill/add-skill.component';
import { LoginComponent } from './Component/login/login.component';
import { EditProfileComponent } from './Component/edit-profile/edit-profile.component';
import { EmployeeComponent } from './Component/employee/employee.component';

import { ManagerComponent } from './Component/manager/manager.component';
import { RegistrationComponent } from './Component/registration/registration.component';
import { WelcomeTemplateComponent } from './Component/welcome-template/welcome-template.component';
import { UpdatePasswordComponent } from './Component/update-password/update-password.component';
import { ViewDetailsComponent } from './Component/view-details/view-details.component';
import { SearchSkillComponent } from './Component/search-skill/search-skill.component';
import { SecurityComponent } from './Component/security/security.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    WelcomeTemplateComponent,
    RegistrationComponent,
    ManagerComponent,
    EmployeeComponent,
    EditProfileComponent,
    AddSkillComponent,
    AddCertificateComponent,
    AddEmployeeComponent,
    UpdatePasswordComponent,
    ViewDetailsComponent,
    SearchSkillComponent,
    SecurityComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
