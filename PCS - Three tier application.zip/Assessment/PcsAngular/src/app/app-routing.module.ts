import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddCertificateComponent } from './Component/add-certificate/add-certificate.component';
import { AddEmployeeComponent } from './Component/add-employee/add-employee.component';
import { AddSkillComponent } from './Component/add-skill/add-skill.component';
import { LoginComponent } from './Component/login/login.component';
import { EditProfileComponent } from './Component/edit-profile/edit-profile.component';
import { EmployeeComponent } from './Component/employee/employee.component';

import { ManagerComponent } from './Component/manager/manager.component';
import { RegistrationComponent } from './Component/registration/registration.component';
import { WelcomeTemplateComponent } from './Component/welcome-template/welcome-template.component';
import { UpdatePasswordComponent } from './Component/update-password/update-password.component';
import { AuthGuard } from './auth.guard';
import { ViewDetailsComponent } from './Component/view-details/view-details.component';
import { SearchSkillComponent } from './Component/search-skill/search-skill.component';
import { SecurityComponent } from './Component/security/security.component';

const routes: Routes = [
  {path: 'login',component: LoginComponent},
  {path: 'welcome',component: WelcomeTemplateComponent},
  {path: 'employee/:id',component: EmployeeComponent,canActivate:[AuthGuard]},
  {path: 'updatePassword/:id',component: UpdatePasswordComponent},
  {path: 'editProfile/:id',component: EditProfileComponent},
  {path: 'addSkill/:id',component: AddSkillComponent},
  {path: 'addEmployee/:id',component: AddEmployeeComponent},
  {path: 'addCertificate/:id',component: AddCertificateComponent},
  {path: 'manager/:id',component: ManagerComponent,canActivate:[AuthGuard]},
  {path: 'viewdetail/:id',component: ViewDetailsComponent},
  {path: 'register',component: RegistrationComponent},
  {path: 'searchskill/:string',component: SearchSkillComponent},
  {path: 'security',component: SecurityComponent},
  

  {path: '', redirectTo:'/welcome', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
