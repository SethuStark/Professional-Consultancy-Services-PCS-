import { Skill } from "./Skill";


export class Employee {
    
    empID:number;
    empName: string;
    empBio: string;
    empEmail: string;
    empPass: string;
    empRole: string = "select";
    
    skill: Skill=new Skill();


    constructor(){}
    
}