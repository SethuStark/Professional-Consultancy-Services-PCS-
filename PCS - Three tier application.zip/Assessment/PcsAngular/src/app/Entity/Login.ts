export class Login {
    empID: number;
    email: string ;
    password: string;
    name: String;
    role: String;

}