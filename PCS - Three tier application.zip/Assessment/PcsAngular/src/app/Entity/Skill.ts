export class Skill {
    
    sId: number;
    sTitle: string ;
    sCategory: string = "select";
    sDesc: string;
    
    constructor(){}
}