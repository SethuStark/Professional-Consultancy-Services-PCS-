import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from '../Entity/employee';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  private baseURL="http://localhost:8080/register";
  constructor(private http: HttpClient) {  }
  createEmployee(emp: Employee): Observable<Object> {
    return this.http.post(`${this.baseURL}`, emp);
  }
}
