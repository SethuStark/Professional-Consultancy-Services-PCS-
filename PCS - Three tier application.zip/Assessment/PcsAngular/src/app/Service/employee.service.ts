import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { Employee } from '../Entity/employee';
import { Skill } from '../Entity/Skill';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
    
  userId:number;
  employeeList : Employee[];
  employee: Employee;
 
  private empURL="http://localhost:8080/employee";
  private mngrURL="http://localhost:8080/manager";
  private skillURL="http://localhost:8080/addSkill";
  private skillSearch="http://localhost:8080/searchskill";
  private skilldelURL="http://localhost:8080/addSkillDel";
  constructor(private http: HttpClient) { 
    
  }

  searchEmpBySkill(search: string) {
    return this.http.get<Employee[]>(`${this.skillSearch}/${search}`);
  }
  
  getEmployeeList(): Observable<Employee[]> {
    return this.http.get<Employee[]>(`${this.empURL}`);
  }
  findEmpById(userId: number): Observable<Employee> {
    return this.http.get<Employee>(`${this.empURL}/${userId}`);
  }
  findMngrById(userId: number) {
    return this.http.get<Employee>(`${this.mngrURL}/${userId}`);
  }
  findSkillById(userId: number): Observable<Skill> {
    return this.http.get<Skill>(`${this.skillURL}/${userId}`);
  }
  saveSkill(skill: Skill): Observable<Object> {
    return this.http.post(`${this.skillURL}`,skill);
  }
  deleteSkill(skill: Skill): Observable<Object> {
    return this.http.post(`${this.skilldelURL}`,skill);
  }
}
