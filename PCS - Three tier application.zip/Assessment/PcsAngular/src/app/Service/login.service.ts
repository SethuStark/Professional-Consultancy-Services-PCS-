import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Login } from '../Entity/Login';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private baseURL="http://localhost:8080/login";
  constructor(private http: HttpClient) { }

  checkUser(login: Login): Observable<Object>{
    return this.http.post(`${this.baseURL}`, login);
  }

  generateToken(login:Login){
    return this.http.post(`${this.baseURL}`, login);
  }
  loginUser(token: string){
    localStorage.setItem("token",token)
    return true;
  }

  isLoggedIn(){
    let token =localStorage.getItem("token");
    if(token==undefined || token==='' || token==null){
      return false;
    }else{
      return true;
    }
  }
  logout(){
    localStorage.removeItem('token');
    return true;
  }

  getToken(){
    return localStorage.getItem("token")
  }
}

