import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/Entity/employee';
import { EmployeeService } from 'src/app/Service/employee.service';


@Component({
  selector: 'app-welcome-template',
  templateUrl: './welcome-template.component.html',
  styleUrls: ['./welcome-template.component.css']
})
export class WelcomeTemplateComponent implements OnInit {
  
  constructor(private empService: EmployeeService,
    private router: Router) { }

  ngOnInit(): void {
    
  }
 
}
