import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from 'src/app/Entity/employee';
import { EmployeeService } from 'src/app/Service/employee.service';
import { Location } from '@angular/common';
import { LoginService } from 'src/app/Service/login.service';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css']
})
export class ViewDetailsComponent implements OnInit {

  empId:number;
  userId:number;
  employee : Employee = new Employee();
  constructor(private location:Location,private route:ActivatedRoute, private empServ:EmployeeService,private router:Router,private loginservice: LoginService) { }

  ngOnInit(): void {
    this.userId = this.route.snapshot.params['id'];
    this.getEmployee();
  }
  getEmployee() {
    this.empServ.findMngrById(this.userId).subscribe( data=> {
      console.log(this.employee);
      this.employee= data;
      
    })
  }
  logoutUser(){
    this.loginservice.logout();
    location.reload();
  }
  goBack() {
    this.location.back();
  }
}
