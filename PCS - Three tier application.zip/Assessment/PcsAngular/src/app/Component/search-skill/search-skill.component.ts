import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { Employee } from 'src/app/Entity/employee';
import { EmployeeService } from 'src/app/Service/employee.service';
import { LoginService } from 'src/app/Service/login.service';

@Component({
  selector: 'app-search-skill',
  templateUrl: './search-skill.component.html',
  styleUrls: ['./search-skill.component.css']
})
export class SearchSkillComponent implements OnInit {

  empList : Employee[];
  search: string;
  userId : number;
  employee: Employee=new Employee;
  constructor(private location: Location,private empService: EmployeeService,
    private router: Router,private route : ActivatedRoute,private loginservice: LoginService) { }

  ngOnInit(): void {
    
    this.userId = this.route.snapshot.params['id'];
    this.search = this.route.snapshot.params['string'];
    this.empService.findMngrById(this.userId).subscribe( data => {
      this.employee = data;
    });
    this.searchSkill();
        
  }
  searchSkill(){
    this.empService.searchEmpBySkill(this.search).subscribe((data: Employee[]) =>{
      
      this.empList=data;
    
    });
  }
  logoutUser(){
    this.loginservice.logout();
    location.reload();
  }
  goBack() {
    this.location.back();
    
  }
}
