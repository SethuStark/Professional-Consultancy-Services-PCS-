import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from 'src/app/Entity/employee';
import { EmployeeService } from 'src/app/Service/employee.service';
import { LoginService } from 'src/app/Service/login.service';


@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  public loggedIn=false;
  
  userId : number;
  emp: Employee=new Employee;
  constructor(private empService: EmployeeService,
    private router: Router,private route : ActivatedRoute,private loginservice: LoginService) { }

  ngOnInit(): void {
    this.userId = this.route.snapshot.params['id'];
    this.empService.findEmpById(this.userId).subscribe( data => {
      this.emp = data;
    });
    
        
  }
  
  logoutUser(){
    this.loginservice.logout();
    location.reload();
  }
 
}