import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from 'src/app/Entity/Login';
import { LoginService } from 'src/app/Service/login.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  credentials={
    username:'',
    password:''
  }

  login:Login=new Login;
  constructor(private loginservice: LoginService,
    private router: Router) { }

  ngOnInit(): void {
  }

  checkuser(){
    this.loginservice.checkUser(this.login).subscribe( (data: any)=>{
      console.log(data);

      if (data.role=="Manager") 
      {
        console.log(data.name);
        this.router.navigate(['manager',data.empId]);
      } 
      else
      {
        console.log(data.name);
        this.router.navigate(['employee',data.empId]);
        
      }
    },
      (  error: any) => console.log(error));
  }
 
    
  onSubmit(){
    console.log(this.login);

    if(this.login.email!='' && this.login.password!=''){
      this.loginservice.generateToken(this.login).subscribe(
         (respone:any)=>{
            console.log(respone.token);
            this.loginservice.loginUser(respone.token);
            this.checkuser();
         },
         error=>{
            console.log(error);
            
         }
      )
    }
    
  }

}
