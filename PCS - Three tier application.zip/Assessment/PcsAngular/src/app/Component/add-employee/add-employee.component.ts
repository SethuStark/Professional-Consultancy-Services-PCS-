import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { RegisterService } from 'src/app/Service/register.service';
import { Location } from '@angular/common';
import { Employee } from 'src/app/Entity/employee';
import { EmployeeService } from 'src/app/Service/employee.service';
import { LoginService } from 'src/app/Service/login.service';


@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  emp:Employee=new Employee;
  userId : number;
  employee: Employee=new Employee;
  roles: Array<string> = ['Employee', 'Manager'];
  categ: Array<string> = ['Sales force', 'React', 'Kubernetes','Selenium Web Driver','Agile Methodology','Angular','JAVA','SDET','GCP'];
  constructor(private location: Location,private regservice: RegisterService,
    private router: Router,private empService: EmployeeService,private route : ActivatedRoute,private loginservice: LoginService) { }

  ngOnInit(): void {
    this.userId = this.route.snapshot.params['id'];
    this.empService.findEmpById(this.userId).subscribe( data => {
      this.employee = data;
    });
  }
  logoutUser(){
    this.loginservice.logout();
    location.reload();
  }
  onSubmit(){
    console.log(this.emp);
    this.saveEmployee();
  }
  goBack() {
    this.location.back();
    
  }

  saveEmployee() {
    this.regservice.createEmployee(this.emp).subscribe( (data: any)=>{
      console.log(data);
      this.goBack();
    },
      (  error: any) => console.log(error));
  }
 
}
