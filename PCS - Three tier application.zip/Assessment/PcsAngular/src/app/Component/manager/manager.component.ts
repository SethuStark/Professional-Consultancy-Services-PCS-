import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from 'src/app/Entity/employee';
import { Skill } from 'src/app/Entity/Skill';
import { EmployeeService } from 'src/app/Service/employee.service';
import { LoginService } from 'src/app/Service/login.service';


@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css']
})
export class ManagerComponent implements OnInit {

  public loggedIn=false;
  private baseurl="http://localhost:8080";
  empList : Employee[];
  search: string;
  size:number;
  skill:Skill=new Skill;
  userId : number;
  employee: Employee=new Employee;
  constructor(private empService: EmployeeService,
    private router: Router,private route : ActivatedRoute,private loginservice: LoginService) { }

  ngOnInit(): void {
    this.loggedIn=this.loginservice.isLoggedIn();
    this.userId = this.route.snapshot.params['id'];
    this.empService.findMngrById(this.userId).subscribe( data => {
      this.employee = data;
    });
    this.getEmployeeList();
        
  }
  searchSkill(){
    this.router.navigate(['searchskill',this.search]);
  }
  getEmployeeList() {
    this.empService.getEmployeeList().subscribe((data: Employee[]) =>{
      
      this.empList=data;
      this.size=this.empList.length;
    });
  }
  logoutUser(){
    this.loginservice.logout();
    location.reload();
  }
  
 
 
}