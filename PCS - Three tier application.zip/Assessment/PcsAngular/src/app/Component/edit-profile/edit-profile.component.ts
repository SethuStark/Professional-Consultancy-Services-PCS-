import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Employee } from 'src/app/Entity/employee';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from 'src/app/Service/employee.service';
import { RegisterService } from 'src/app/Service/register.service';
import { LoginService } from 'src/app/Service/login.service';
@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {

  emp:Employee=new Employee;
  userId : number;
  constructor(private location: Location,private empService: EmployeeService,
    private router: Router,private route : ActivatedRoute,private regservice: RegisterService,private loginservice: LoginService) { }

  ngOnInit(): void {
    this.userId = this.route.snapshot.params['id'];
    this.empService.findMngrById(this.userId).subscribe( data => {
      this.emp = data;
    });
   
  }onSubmit(){
    console.log(this.emp);
    this.saveEmployee();
  }
  goBack() {
    this.location.back();
    
  }
  logoutUser(){
    this.loginservice.logout();
    location.reload();
  }
  saveEmployee() {
    this.regservice.createEmployee(this.emp).subscribe( (data: any)=>{
      console.log(data);
      this.goBack();
    },
      (  error: any) => console.log(error));
  }
  updPass(){
    this.router.navigate(['updatePassword',this.userId]);
  }
}
