import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/Entity/employee';
import { RegisterService } from 'src/app/Service/register.service';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  emp:Employee=new Employee();
  
  roles: Array<string> = ['Employee', 'Manager'];
  categ: Array<string> = ['Sales force', 'React', 'Kubernetes','Selenium Web Driver','Agile Methodology','Angular','JAVA','SDET','GCP'];
  constructor(private regservice: RegisterService,
    private router: Router) { }

  ngOnInit(): void {
  }
  onSubmit(){
    console.log(this.emp);
    this.saveEmployee();
  }
  saveEmployee() {
    this.regservice.createEmployee(this.emp).subscribe( (data: any)=>{
      console.log(data);
      this.goToLogin();
    },
      (  error: any) => console.log(error));
  }
  goToLogin() {
    this.router.navigate(['/login']);
  }
}
