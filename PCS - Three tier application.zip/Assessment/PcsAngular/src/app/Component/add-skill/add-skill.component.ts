import { Component, OnInit } from '@angular/core';
import { Skill } from 'src/app/Entity/Skill';
import { Location } from '@angular/common';
import { EmployeeService } from 'src/app/Service/employee.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from 'src/app/Entity/employee';
import { LoginService } from 'src/app/Service/login.service';

@Component({
  selector: 'app-add-skill',
  templateUrl: './add-skill.component.html',
  styleUrls: ['./add-skill.component.css']
})
export class AddSkillComponent implements OnInit {

  skill: Skill=new Skill;
  userId : number;
  employee: Employee=new Employee;
  categ: Array<string> = ['Sales force', 'React', 'Kubernetes','Selenium Web Driver','Agile Methodology','Angular','JAVA','SDET','GCP'];
  constructor(private location: Location,private empService: EmployeeService,
    private router: Router,private route : ActivatedRoute,private loginservice: LoginService) { }

  ngOnInit(): void {
    this.userId = this.route.snapshot.params['id'];
    this.empService.findSkillById(this.userId).subscribe( data => {
      this.skill = data;
    });
    this.empService.findEmpById(this.userId).subscribe( data => {
      this.employee = data;
    });
  }
  logoutUser(){
    this.loginservice.logout();
    location.reload();
  }
  onSubmit(){
    console.log(this.skill);
    this.saveSkill();
  }
  saveSkill() {
    this.empService.saveSkill(this.skill).subscribe( (data: any)=>{
      console.log(data);
      this.goBack();
    },
      (  error: any) => console.log(error));
  }
  deleteSkill(){
    this.empService.deleteSkill(this.skill).subscribe( (data: any)=>{
      console.log(data);
      this.goBack();
    },
      (  error: any) => console.log(error));
  }
  goBack() {
    this.location.back();
    
  }

}
