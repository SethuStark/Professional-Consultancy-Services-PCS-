import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Employee } from 'src/app/Entity/employee';
import { EmployeeService } from 'src/app/Service/employee.service';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { LoginService } from 'src/app/Service/login.service';
@Component({
  selector: 'app-add-certificate',
  templateUrl: './add-certificate.component.html',
  styleUrls: ['./add-certificate.component.css']
})
export class AddCertificateComponent implements OnInit {

  selectedFile: File;
  retrievedImage: any;
  base64Data: any;
  retrieveResonse: any;
  message: string;
  imageName: any;
  userId : number;
  employee: Employee=new Employee;
  constructor(private empService: EmployeeService,private route : ActivatedRoute,private location: Location,private httpClient: HttpClient,private loginservice: LoginService) { }

  ngOnInit(): void {
    this.userId = this.route.snapshot.params['id'];
    this.empService.findEmpById(this.userId).subscribe( data => {
      this.employee = data;
    });
  }

 
  logoutUser(){
    this.loginservice.logout();
    location.reload();
  }

  
  onUpload() {
    console.log(this.selectedFile);
    
    
    const uploadImageData = new FormData();
    uploadImageData.append('imageFile', this.selectedFile, this.selectedFile.name);
  
    
    this.httpClient.post(`http://localhost:8080/addCertificate/${this.userId}`, uploadImageData, { observe: 'response' })
      .subscribe((response) => {
        if (response.status === 200) {
          this.message = 'Image uploaded successfully';
        } else {
          this.message = 'Image not uploaded successfully';
        }
      }
      
      );
      this.goBack();

  }
  goBack() {
    this.location.back();
    
  }
  public onFileChanged(event: { target: { files: File[]; }; }) {
    //Select File
    this.selectedFile = event.target.files[0];
  }

    //Gets called when the user clicks on retieve image button to get the image from back end
    getImage() {
    //Make a call to Sprinf Boot to get the Image Bytes.
    this.httpClient.get('http://localhost:8080/image/get/' + this.imageName)
      .subscribe(
        res => {
          this.retrieveResonse = res;
          this.base64Data = this.retrieveResonse.picByte;
          this.retrievedImage = 'data:image/jpeg;base64,' + this.base64Data;
        }
      );
  }
}
